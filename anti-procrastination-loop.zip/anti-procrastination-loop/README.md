# BREAK THE LOOP — Procrastination

A deploy-ready, client-side web app designed as an immediate intervention tool for procrastination.

## What it does

It is deliberately NOT a productivity dashboard. It is for the moment you catch yourself escaping into scrolling, organizing, overthinking, or "I'll do it later."

Flow:

1. Name the loop.
2. Identify the task.
3. Receive a context-specific dare.
4. Choose 1/3/5/10 minutes.
5. Do the task with no renegotiation.
6. Reassess whether the task moved.
7. Reinforce progress or shrink the next dare.
8. Return to life instead of endlessly optimizing the app.

It also has a low-mood path that uses gentle activation language and a safety note. It does not diagnose depression or claim to treat it.

## Psychology used

The design is informed by:
- procrastination research on task aversiveness, delay, self-efficacy, impulsiveness and self-control
- emotion-regulation / short-term mood-repair models of procrastination
- implementation intentions ("if X, then Y")
- behavioral activation / activity scheduling principles
- environmental friction and cue control
- self-compassion without removing accountability
- temporal motivation / immediate-vs-delayed reward dynamics

The app intentionally turns those ideas into tiny behavioral experiments rather than presenting them as therapy.

## Sources

- Steel (2007), Psychological Bulletin — https://pubmed.ncbi.nlm.nih.gov/17201571/
- Sirois / APA — https://www.apa.org/news/podcasts/speaking-of-psychology/procrastinate
- Gollwitzer et al. — https://pubmed.ncbi.nlm.nih.gov/17295981/
- Belanger et al. — https://pubmed.ncbi.nlm.nih.gov/25965276/
- van Eerde & Klingsieck — https://pubmed.ncbi.nlm.nih.gov/30214421/
- Cuijpers et al. (2026) — https://pubmed.ncbi.nlm.nih.gov/42492146/
- Stress context vulnerability model — https://pubmed.ncbi.nlm.nih.gov/36981941/

## Quotes

The quote library is short on purpose. The app can rotate quotes, but it should not become a quote-scrolling procrastination machine.

One quote was included from the user-provided reference image: Richard Feynman's "The first principle..." line. Another commonly attributed line is explicitly marked as "often attributed" where attribution is uncertain.

## GitHub Pages

Upload the contents of this folder to a repository.

GitHub:
Settings → Pages → Deploy from a branch → main → /(root)

No npm, build step, API key, database, or server is required.

## Privacy

This MVP does not transmit or persist sensitive session data. It is intentionally stateless.

## Safety

This is an educational self-help tool, not medical care. Persistent or severe low mood, hopelessness, loss of interest, or impaired functioning deserves appropriate professional support. If there is immediate danger or risk of self-harm, use appropriate local emergency/crisis resources rather than relying on this app.
