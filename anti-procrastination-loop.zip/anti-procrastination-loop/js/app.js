
document.addEventListener("DOMContentLoaded",()=>{
 const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
 const screens=$$(".screen"); let reason=null,targetType=null,task="",minutes=3,timer=null,remaining=0,lastDare=null,used=[];
 const show=name=>{screens.forEach(x=>x.classList.toggle("active",x.dataset.screen===name));$("#app").scrollIntoView({behavior:"smooth",block:"start"})};
 const pick=(arr)=>arr[Math.floor(Math.random()*arr.length)];
 const reasonLabel={backlog:"BACKLOG",hard:"DIFFICULTY",fear:"FEAR OF FAILURE",perfection:"PERFECTIONISM",bored:"BOREDOM",distracted:"DISTRACTION",lowenergy:"LOW ENERGY",lowmood:"LOW MOOD",dontknow:"UNCLEAR"};
 const start=()=>{show("reason");window.scrollTo({top:document.querySelector(".app").offsetTop-40,behavior:"smooth"})};
 $("#startBtn").onclick=start;
 $("#libraryBtn").onclick=()=>$("#library").scrollIntoView({behavior:"smooth"});

 $$("[data-reason]").forEach(b=>b.onclick=()=>{
   reason=b.dataset.reason;
   if(reason==="lowmood"){show("lowmood");return;}
   show("target");
 });
 $$("[data-target]").forEach(b=>b.onclick=()=>{targetType=b.dataset.target;$("#taskInput").focus()});
 $("#targetNext").onclick=()=>{
   task=$("#taskInput").value.trim()||"the thing I've been avoiding";
   buildDare();
 };
 const renderLibrary=()=>{
   $("#psychologyCards").innerHTML=window.PSYCHOLOGY.map(x=>`<article class="psych-card"><h3>${x.title}</h3><p>${x.text}</p></article>`).join("");
   $("#sources").innerHTML="<strong>Research used for the design</strong><br>"+window.SOURCES.map(s=>`<a href="${s[1]}" target="_blank" rel="noopener">${s[0]}</a>`).join("<br>");
 };
 renderLibrary();

 function buildDare(){
   const pool=(window.DARES[reason]||window.DARES.dontknow);
   let candidates=pool.filter(x=>!used.includes(x[0]));
   if(!candidates.length){used=[];candidates=pool}
   lastDare=pick(candidates); used.push(lastDare[0]);
   $("#modeLabel").textContent=reasonLabel[reason]||"INTERVENTION";
   $("#interventionTitle").textContent=lastDare[0];
   $("#dareText").textContent=lastDare[1];
   $("#whyText").textContent=lastDare[2];
   show("intervention");
 }
 $$(".timer-pick button").forEach(b=>b.onclick=()=>{
   $$(".timer-pick button").forEach(x=>x.classList.remove("selected"));b.classList.add("selected");minutes=+b.dataset.min;
 });
 $("#changeDare").onclick=buildDare;
 $("#acceptDare").onclick=()=>{
   $("#taskChip").textContent=task;
   $("#timerTitle").textContent=lastDare[0];
   $("#timerSub").textContent=minutes===1?"One minute. That's all.":"For this timer, no renegotiation. You are allowed to stop when it ends.";
   startTimer(minutes*60);show("timer");
 };
 function renderTimer(){const m=Math.floor(remaining/60),s=remaining%60;$("#countdown").textContent=`${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`}
 function startTimer(sec){clearInterval(timer);remaining=sec;renderTimer();timer=setInterval(()=>{remaining--;renderTimer();if(remaining<=0){clearInterval(timer);show("reassess")}},1000)}
 function reassess(){clearInterval(timer);show("reassess")}
 $("#timerDone").onclick=reassess; $("#timerSkip").onclick=reassess;
 $$("[data-result]").forEach(b=>b.onclick=()=>{
   if(b.dataset.result==="yes"){
     const q=pick(window.QUOTES);$("#quoteText").textContent=`“${q.text}”`;$("#quoteAuthor").textContent="— "+q.author;
     $("#winTitle").textContent=reason==="backlog"?"The backlog just got smaller.":"You moved the task.";
     $("#winText").textContent="Notice what just happened: you did not need to feel ready before acting. You made the next action happen.";
     show("win");
   }else{
     const pool=window.DARES[reason]||window.DARES.dontknow;const d=pick(pool);
     $("#retryDare").textContent=d[1];$("#retryWhy").textContent=d[2];lastDare=d;show("retry");
   }
 });
 $("#retryAccept").onclick=()=>{ $("#taskChip").textContent=task;startTimer(60);show("timer") };
 $("#retryReset").onclick=()=>show("reason");
 $("#continueWork").onclick=()=>{minutes=5;$("#timerTitle").textContent="Five more minutes.";$("#timerSub").textContent="You already started. Keep the momentum.";startTimer(300);show("timer")};
 $("#finishSession").onclick=()=>{show("reason");$("#taskInput").value="";window.scrollTo({top:0,behavior:"smooth"})};
 $$("[data-low]").forEach(b=>b.onclick=()=>{
   if(b.dataset.low==="task"){reason="lowmood";task=$("#taskInput").value.trim()||"one tiny useful thing";buildDare();}
   else {
     const msgs={body:"Good. Do that now. When you're done, come back only if you want the next step.",environment:"Good. Change rooms first. Then decide whether you want a tiny task.",person:"Good. Connection before productivity is allowed. You can come back after you've reached out."};
     alert(msgs[b.dataset.low]);
   }
 });
});
