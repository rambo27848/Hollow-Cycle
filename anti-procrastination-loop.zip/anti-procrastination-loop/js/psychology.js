
window.PSYCHOLOGY = [
 {title:"Short-term mood repair",text:"Procrastination can function as immediate relief from task-related discomfort. The app therefore reduces the emotional cost of starting instead of only shouting “be disciplined.”"},
 {title:"Task aversiveness",text:"When a task feels unpleasant, difficult, boring, threatening or uncertain, avoidance becomes more tempting. Micro-dares lower the first barrier rather than demanding a heroic session."},
 {title:"Implementation intentions",text:"An if–then plan links a recognizable situation to a specific response: “If I catch myself scrolling while I should study, then I put the phone away and open the exact task.”"},
 {title:"Behavioral activation",text:"Action can precede motivation. The app emphasizes small, concrete activity and contact with meaningful tasks rather than waiting to feel ready."},
 {title:"Self-compassion without passivity",text:"Shame can become another reason to escape. We use non-judgmental language while still requiring a next action: kind to the person, strict about the next move."},
 {title:"Temporal motivation",text:"Immediate rewards can beat distant rewards. Making the first action immediate and tiny helps reduce the gap between intention and action."},
 {title:"Environmental design",text:"When distraction is close and friction is low, intentions are easier to derail. Some dares therefore change the environment: phone away, room change, public space, or visible task."},
 {title:"Fear and perfectionism",text:"A threatening standard can make starting costly. Deliberately allowing an imperfect first attempt can make initiation easier: draft first, evaluate later."}
];

window.SOURCES = [
 ["Steel (2007), Psychological Bulletin — meta-analytic review of procrastination","https://pubmed.ncbi.nlm.nih.gov/17201571/"],
 ["Sirois / APA — procrastination and short-term mood repair","https://www.apa.org/news/podcasts/speaking-of-psychology/procrastinate"],
 ["Gollwitzer et al. — implementation intentions and goal attainment","https://pubmed.ncbi.nlm.nih.gov/17295981/"],
 ["Belanger et al. (2015) — implementation intentions meta-analysis in mental-health samples","https://pubmed.ncbi.nlm.nih.gov/25965276/"],
 ["van Eerde & Klingsieck (2018) — psychological treatments for procrastination","https://pubmed.ncbi.nlm.nih.gov/30214421/"],
 ["Cuijpers et al. (2026) — behavioral activation systematic review/meta-analysis","https://pubmed.ncbi.nlm.nih.gov/42492146/"],
 ["Sirois et al. — stress context vulnerability model of procrastination","https://pubmed.ncbi.nlm.nih.gov/36981941/"]
];
