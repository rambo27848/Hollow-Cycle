
window.QUOTES = [
 {text:"The first principle is that you must not fool yourself—and you are the easiest person to fool.",author:"Richard Feynman"},
 {text:"Well begun is half done.",author:"Aristotle"},
 {text:"The secret of getting ahead is getting started.",author:"Mark Twain"},
 {text:"Great acts are made up of small deeds.",author:"Lao Tzu"},
 {text:"It is not enough to be busy. So are the ants. The question is: What are we busy about?",author:"Henry David Thoreau"},
 {text:"You cannot plow a field by turning it over in your mind.",author:"Gordon B. Hinckley"},
 {text:"Do not wait for the perfect moment. Take the moment and make it perfect.",author:"Zig Ziglar"},
 {text:"The trouble with the world is that the foolish are cocksure and the intelligent are full of doubt.",author:"Often attributed to Bertrand Russell"}
];

window.DARES = {
 backlog:[
  ["Shrink the mountain.","Write down only the next physical action for the most urgent task. Ignore the rest for 3 minutes.","A giant backlog creates an impossible-looking decision. We only need one executable move."],
  ["Open the oldest avoided item.","Open the exact file, lecture, assignment or page. Do not organize anything else.","Opening the avoided object removes uncertainty without demanding completion."],
  ["Pick the 1% move.","Do one question, one paragraph, one calculation, or one line of code.","The goal is movement, not backlog elimination."]
 ],
 hard:[
  ["Make it stupidly easy.","Do the easiest meaningful part of the task for 3 minutes.","Difficulty increases the emotional cost of starting. Lower the entry cost."],
  ["Bad first attempt.","Produce an intentionally rough first version. No polishing.","Perfection is not allowed during the first pass. Creation first, evaluation later."],
  ["Ask the first question.","Write: “What is the first thing I need to understand?” Then answer it.","Turning vague difficulty into a concrete question reduces ambiguity."]
 ],
 fear:[
  ["Make failure cheap.","Do a deliberately imperfect first attempt for 3 minutes.","You are not proving your ability. You are collecting information."],
  ["Expose yourself to the task.","Open it and work until you encounter the first thing you don't know.","Avoidance protects fear in the short term; contact gives you real information."],
  ["Lower the standard.","Your only requirement is: produce something that can be improved.","A bad draft is editable. An empty page is not."]
 ],
 perfection:[
  ["Make it ugly.","Write the worst acceptable first draft.","Perfectionism often makes starting feel like a final exam. This is only version 0.1."],
  ["No editing allowed.","Create for 3 minutes without correcting yourself.","Separating creation from evaluation removes a common source of friction."],
  ["Submit to the future.","Do the smallest version that your future self could improve.","Progress requires an object to improve."]
 ],
 bored:[
  ["Race the clock.","Set 3 minutes. See how much you can move before it ends.","A short challenge can make an otherwise dull task more immediately salient."],
  ["Change the channel.","Change location, put the phone away, and start the task there.","Changing context can interrupt an automatic distraction routine."],
  ["Find one interesting question.","Turn the task into one question you genuinely want answered.","Curiosity can make a low-value task more engaging."]
 ],
 distracted:[
  ["Phone exile.","Put the phone outside arm's reach. Then open the task.","Don't negotiate with a distraction that is physically beside you."],
  ["One-tab rule.","Close everything except the material needed for this task.","Reduce competing cues before demanding concentration."],
  ["Browser barricade.","Close the distracting tab and start the smallest useful action.","The first intervention is removing the immediate cue, not trying harder."]
 ],
 lowenergy:[
  ["Minimum viable work.","Do one tiny useful action, then reassess.","Low energy calls for a smaller dose, not a lecture about character."],
  ["Body reset.","Stand up, drink water, change rooms, then do 1 minute of the task.","A state change can make the next action easier."],
  ["Do the mechanical part.","Choose the least cognitively demanding useful step.","You can preserve deep work for when your energy returns."]
 ],
 dontknow:[
  ["Mystery dare.","Open the task you've been avoiding. Look at it for 60 seconds. Then choose one visible next action.","You don't need a perfect diagnosis to begin experimenting."],
  ["Start anywhere.","Pick the first obvious physical action and do it for 3 minutes.","Action can reveal what the actual obstacle is."],
  ["Name the feeling.","Write one word: bored, afraid, overwhelmed, tired, confused, resentful, or other. Then start for 1 minute.","Naming the obstacle can make an invisible loop more concrete."]
 ],
 lowmood:[
  ["Tiny contact.","Open the task and do one tiny useful action. Stop after 1 minute if needed.","When mood is low, the target is gentle activation, not heroic productivity."],
  ["Change state first.","Stand up, drink water, wash your face, and change rooms.","A small behavioral shift can be easier than trying to think yourself into motivation."],
  ["Reconnect.","Message someone you trust, then choose one tiny task action.","Isolation and avoidance can reinforce each other; connection is one possible interruption."]
 ]
};
